import random

import pygame
import sys

pygame.init() #инициализация pygme
size = width, height = [1000, 1000] #размер консоли

screen = pygame.display.set_mode(size) #отрисовка консоли
clock = pygame.time.Clock() #часы для регулировки частоты кадров

points = [] #список точек от куда будут появляться частицы
particles = [] #частицы


def update():
    mp = pygame.mouse.get_pos()

    for point in points:
        #начальная позиция берется из points
        particle = {
            "pos": [
                point[0],
                point[1]
            ],
        #скорость перемещения частицы по x и y
            "velocity": [
                random.uniform(-0.5, 0.5), -1
            ],
        #время жизни частицы
            "life": 255,
        #цвет частицы
            "color": [0, 50, 255]
        }

        particles.append(particle)


    for p in particles:
        #изменение положения частицы относительно указанной выше скорости
        p['pos'][0] += p['velocity'][0]
        p['pos'][1] += p['velocity'][1]
        #изменение жизни частицы
        p['life'] -= 1
        #изменение цвета частицы
        p['color'][1] += 3

        #удаление частицы из списка когда её жизнь < 0
        if p['life'] <= 0:
            particles.remove(p)


def render():
    for p in particles:
        k = p['life'] / 255 #текущая жизнь частицы

        #отрисовка частицы в консоли
        pygame.draw.circle(
            screen,
            ((p['color'][0] * k), p['color'][1] * k, p['color'][2] * k),
            p['pos'],
            10)


while True:
    for event in pygame.event.get():
        #выход по нажатию на крестик в консоли
        if event.type == pygame.QUIT:
            sys.exit()
        #добавление в список points точки, из которой будут появляться частицы кликом мышки
        if event.type == pygame.MOUSEBUTTONUP:
            points.append(event.pos)

    #обновление данных в списках
    update()
    #очистака экрана перед следующей отрисовкой
    screen.fill((0, 0, 0))
    #отрисовка
    render()

    pygame.display.update()

    #кадры в секунду
    clock.tick(75)
